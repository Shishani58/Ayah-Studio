# Call route endpoints directly: these regressions exercise project state and
# SQLite writes without requiring an HTTP client or real alignment models.
import sqlite3
from pathlib import Path
from types import SimpleNamespace

import pytest
from fastapi import HTTPException

from surah_cutter.data.project_db import ProjectDB
from surah_cutter.webgui import server
from surah_cutter.webgui.server import _fast_trace_summary
from surah_cutter.webgui.state import AppState, DB_CODE, DB_VERSION, classify_status


def test_fast_trace_summary_exposes_forecast_and_atomic_fallbacks():
    summary = _fast_trace_summary(
        {
            "ayahs": [
                {"ayah": 1, "reliable": True},
                {"ayah": 2, "repaired": True},
            ],
            "tempo_forecast": {
                "rate_units_per_ms": 0.12,
                "confidence": 0.8,
                "observation_count": 3,
            },
            "pause_sequence_events": [
                {"action": "unresolved_current", "ayah": 2},
                {"action": "unresolved_current", "ayah": 2},
            ],
            "model_reads": [
                {"phase": "wasl-run", "atomic": True},
                {"phase": "wasl-tiled-fallback", "atomic": True},
                {"phase": "wasl-run", "atomic": False},
            ],
        }
    )

    assert summary["tempo_rate"] == 0.12
    assert summary["tempo_confidence"] == 0.8
    assert summary["tempo_observations"] == 3
    assert summary["unresolved"] == 1
    assert summary["atomic_wasl_reads"] == 2


@pytest.fixture
def project(tmp_path, monkeypatch):
    from surah_cutter.core import decode

    state = AppState()
    state.set_db_path(str(tmp_path / "a.db"))
    state.audio_map = {113: tmp_path / "a/113.mp3", 114: tmp_path / "a/114.mp3"}
    with ProjectDB.open(str(state.db_path), DB_CODE, DB_VERSION):
        pass
    monkeypatch.setattr(server, "STATE", state)
    monkeypatch.setattr(server, "_JOB", None)
    monkeypatch.setattr(server.settings, "update", lambda **kwargs: kwargs)
    monkeypatch.setattr(decode, "duration_ms", lambda _: 30000)
    return state


def endpoint(path):
    return next(route.endpoint for route in server.app.routes if route.path == path)


@pytest.mark.parametrize("path", ["/api/settings", "/api/generate/preview", "/api/generate"])
def test_removed_auto_mode_is_rejected_before_start(project, path):
    with pytest.raises(HTTPException, match="unknown mode") as error:
        endpoint(path)({"mode": "auto", "suras": [114]})
    assert error.value.status_code == 400
    assert server._JOB is None


def timings(path):
    with sqlite3.connect(path) as conn:
        return conn.execute("SELECT sura, ayah, time FROM timings ORDER BY sura, ayah").fetchall()


def test_audio_clip_route_preserves_project_and_uses_explicit_range(project, monkeypatch):
    from surah_cutter.webgui import playback

    calls = []
    monkeypatch.setattr(playback, "audio_clip", lambda *args: calls.append(args) or b"wav")
    before = project.db_path.read_bytes()
    response = endpoint("/api/audio/{surah}/clip")(114, 120, 6483)
    assert calls == [(project.audio_map[114], 120, 6483)]
    assert response.body == b"wav" and response.media_type == "audio/wav"
    assert project.db_path.read_bytes() == before
    with pytest.raises(HTTPException) as error:
        endpoint("/api/audio/{surah}/clip")(112, 0, 1000)
    assert error.value.status_code == 404


def test_audio_clip_route_rejects_bad_range(project, monkeypatch):
    from surah_cutter.webgui import playback

    def invalid(*args):
        raise ValueError("Invalid audio range")

    monkeypatch.setattr(playback, "audio_clip", invalid)
    with pytest.raises(HTTPException) as error:
        endpoint("/api/audio/{surah}/clip")(114, 100, 20)
    assert error.value.status_code == 400


def test_ayah_review_status_round_trip_preserves_time(project):
    with ProjectDB.open(str(project.db_path), DB_CODE, DB_VERSION) as db:
        db.set_time(114, 1, 5614)
    verify = endpoint("/api/verify")
    for status in ("verified", "edited", "auto"):
        verify({"surah": 114, "ayah": 1, "status": status, "db_path": str(project.db_path)})
        ayah = endpoint("/api/sura/{surah}")(114)["ayahs"][0]
        assert (ayah["status"], ayah["time"]) == (status, 5614)
    with ProjectDB.open(str(project.db_path), DB_CODE, DB_VERSION) as db:
        db.set_status(114, 1, "edited")
        assert db.write_timings([(114, 1, 9999)], source="auto") == 0


def test_generation_reruns_changed_mode_and_keeps_manual_marks(project, monkeypatch):
    from surah_cutter.core import pipeline
    from surah_cutter.core import full_windows

    calls = []

    def align(audio, surah, **kwargs):
        mode = kwargs["mode"]
        calls.append(mode)
        confidence = 0.2 if mode == "fast" else 0.9
        kwargs["trace"].update(mode=mode, model_source="onnx-ctc:quran-phonetics", ayahs=[
            {"ayah": a, "conf": confidence} for a in range(1, 7)
        ])
        if mode == "full":
            kwargs["trace"]["full_windows"] = {
                "algorithm": full_windows.FULL_POLICY, "window_s": 20, "workers": 3,
                "context_s": 2, "max_window_s": 60, "onset_policy": full_windows.FULL_ONSET_POLICY,
                "pause_policy": "strong-dsp-v1",
            }
        return [(surah, a, a * 1000 + (100 if mode == "full" else 0)) for a in range(1, 7)]

    monkeypatch.setattr(pipeline, "process_surah", align)
    monkeypatch.setattr(server._GenJob, "start", server._GenJob._run)
    monkeypatch.setattr(server.model_store, "active_kind", lambda: "phonetic")
    monkeypatch.setattr(server.model_store, "ACTIVE_ID", "quran-phonetics")
    generate = endpoint("/api/generate")
    generate({"suras": [114], "mode": "fast", "only_missing": True})
    with ProjectDB.open(str(project.db_path), DB_CODE, DB_VERSION) as db:
        db.set_time(114, 1, 999)
        db.set_status(114, 2, "verified")
        protected = [db.get_review(114, a) for a in (1, 2)]
    assert generate({"suras": [114], "mode": "full", "only_missing": True})["suras"] == [114]
    assert calls == ["fast", "full"]
    ayahs = endpoint("/api/sura/{surah}")(114)["ayahs"]
    assert [a["time"] for a in ayahs] == [999, 2000, 3100, 4100, 5100, 6100]
    assert [a["confidence"] for a in ayahs] == [None, 0.2, 0.9, 0.9, 0.9, 0.9]
    with ProjectDB.open(str(project.db_path), DB_CODE, DB_VERSION) as db:
        assert [db.get_review(114, a) for a in (1, 2)] == protected
        assert "requested_mode=full" in db.get_review(114, 3)["source"]
    assert endpoint("/api/suras")()[-1]["alignment_modes"] == ["full"]
    assert generate({"suras": [114], "mode": "full", "only_missing": True})["suras"] == [114]
    assert calls == ["fast", "full", "full"]
    with ProjectDB.open(str(project.db_path), DB_CODE, DB_VERSION) as db:
        assert [db.get_review(114, a) for a in (1, 2)] == protected


def test_explicit_mode_resume_recalculates_unknown_and_mixed_modes(project, monkeypatch):
    with ProjectDB.open(str(project.db_path), DB_CODE, DB_VERSION) as db:
        db.write_timings([(114, a, a * 1000) for a in range(1, 7)], source="legacy")
    starts = []
    monkeypatch.setattr(server._GenJob, "start", lambda job, suras, mode: starts.append(suras))
    assert endpoint("/api/generate")({"suras": [114], "mode": "full", "only_missing": True})["suras"] == [114]
    with ProjectDB.open(str(project.db_path), DB_CODE, DB_VERSION) as db:
        db.write_timings([(114, a, a * 1000) for a in range(1, 7)], source="test:requested_mode=full")
        db.write_timings([(114, 6, 6000)], source="test:requested_mode=fast")
    assert endpoint("/api/suras")()[-1]["alignment_modes"] == ["fast", "full"]
    assert endpoint("/api/generate")({"suras": [114], "mode": "full", "only_missing": True})["suras"] == [114]
    with ProjectDB.open(str(project.db_path), DB_CODE, DB_VERSION) as db:
        for a in range(1, 7):
            db.set_status(114, a, "verified")
    assert endpoint("/api/suras")()[-1]["alignment_modes"] == []
    with pytest.raises(HTTPException, match="all done"):
        endpoint("/api/generate")({"suras": [114], "mode": "full", "only_missing": True})


def test_manual_time_invalidates_confidence_even_after_verification(project):
    with ProjectDB.open(str(project.db_path), DB_CODE, DB_VERSION) as db:
        db.write_timings([(114, 1, 1000)], source="test", confidence=0.9)
        db.set_time(114, 1, 1100)
        db.set_status(114, 1, "verified")
        # Keep the historic model evidence, but don't present it for a manual time.
        assert db.get_review(114, 1)["confidence"] == 0.9
    assert endpoint("/api/sura/{surah}")(114)["ayahs"][0]["confidence"] is None


@pytest.mark.parametrize("payload", [
    {"surah": 114, "ayah": 7},
    {"surah": 114, "ayah": True},
    {"surah": "114", "ayah": 1},
    {"surah": 114, "ayah": 1, "status": "bad"},
    {"surah": 114, "ayah": 1, "status": "verified"},
    {"surah": 114, "ayah": 1, "status": "edited"},
])
def test_ayah_review_status_rejects_invalid_or_missing_timing(project, payload):
    with pytest.raises(HTTPException) as exc:
        endpoint("/api/verify")(payload)
    assert exc.value.status_code == 400
    with ProjectDB.open(str(project.db_path), DB_CODE, DB_VERSION) as db:
        assert db.get_review(114, 1) is None


def test_ayah_review_status_rejects_changed_project(project, tmp_path):
    with pytest.raises(HTTPException) as exc:
        endpoint("/api/verify")({
            "surah": 114, "ayah": 1, "status": "auto", "db_path": str(tmp_path / "old.db"),
        })
    assert exc.value.status_code == 409
    assert timings(project.db_path) == []


@pytest.mark.parametrize("time", [1000, 1001])
def test_manual_start_rejects_end_of_real_audio(project, monkeypatch, tmp_path, time):
    import wave

    from surah_cutter.core import decode

    audio = tmp_path / "114.wav"
    with wave.open(str(audio), "wb") as wav:
        wav.setparams((1, 2, 16000, 0, "NONE", "not compressed"))
        wav.writeframes(b"\0\0" * 16000)
    project.audio_map[114] = audio
    # Exercise exact decoding rather than trusting container/browser duration.
    monkeypatch.setattr(decode, "duration_ms", lambda path: round(len(decode.decode(path)) / 16))
    with ProjectDB.open(str(project.db_path), DB_CODE, DB_VERSION) as db:
        db.set_time(114, 6, 999)
    with pytest.raises(HTTPException) as error:
        endpoint("/api/timing")({"surah": 114, "ayah": 6, "time": time})
    assert error.value.status_code == 400
    assert timings(project.db_path) == [(114, 6, 999)]
    assert endpoint("/api/timing")({"surah": 114, "ayah": 6, "time": 999})["ok"]
    assert endpoint("/api/verify")({"surah": 114, "ayah": 6})["ok"]


@pytest.mark.parametrize("status", ["edited", "verified"])
@pytest.mark.parametrize("time", [30000, 30001])
def test_review_status_rejects_saved_start_outside_audio(project, status, time):
    with ProjectDB.open(str(project.db_path), DB_CODE, DB_VERSION) as db:
        db.write_timings([(114, 6, time)], "test")
        before = db.get_review(114, 6)
    with pytest.raises(HTTPException) as error:
        endpoint("/api/verify")({"surah": 114, "ayah": 6, "status": status})
    assert error.value.status_code == 400
    with ProjectDB.open(str(project.db_path), DB_CODE, DB_VERSION) as db:
        assert db.get_review(114, 6) == before
        assert db._conn.execute("SELECT COUNT(*) FROM edit_history").fetchone()[0] == 0


@pytest.mark.parametrize("audio_state", ["missing", "unreadable"])
def test_manual_review_requires_readable_audio(project, monkeypatch, audio_state):
    from surah_cutter.core import decode

    if audio_state == "missing":
        project.audio_map.clear()
    else:
        def fail(path):
            raise decode.DecodeError("bad audio")
        monkeypatch.setattr(decode, "duration_ms", fail)
    with ProjectDB.open(str(project.db_path), DB_CODE, DB_VERSION) as db:
        db.write_timings([(114, 1, 1000)], "test")
    for route, payload in (("/api/timing", {"time": 1100}), ("/api/verify", {})):
        with pytest.raises(HTTPException) as error:
            endpoint(route)({"surah": 114, "ayah": 1, **payload})
        assert error.value.status_code == 400
    assert endpoint("/api/verify")({"surah": 114, "ayah": 1, "status": "auto"})["ok"]
    assert timings(project.db_path) == [(114, 1, 1000)]


def test_saved_sura_logs_list_pairs_and_read_full_data(project):
    lines = [f"line {i}" for i in range(300)]
    paths = server._save_sura_log(114, "fast", {"phase": "complete"}, lines, [], project.db_path)
    server._save_sura_log(113, "full", {}, ["other sura"], [], project.db_path)
    folder = Path(paths["log"]).parent
    (folder / "sura_114_words.json").write_text('{"words": []}', encoding="utf-8")
    entries = endpoint("/api/sura/{surah}/logs")(114)["logs"]
    assert {item["id"] for item in entries} == {"sura_114_fast", "sura_114_words"}
    result = endpoint("/api/sura/{surah}/logs/{log_id}")(114, "sura_114_fast")
    assert result["log"].splitlines() == lines
    assert '"phase": "complete"' in result["json"]
    json_only = endpoint("/api/sura/{surah}/logs/{log_id}")(114, "sura_114_words")
    assert json_only["log"] is None
    assert json_only["json"] == '{"words": []}'


def test_saved_sura_logs_reject_other_sura_paths_and_links(project, tmp_path):
    folder = project.db_path.with_name(f"{project.db_path.stem}.logs")
    folder.mkdir()
    secret = tmp_path / "secret.log"
    secret.write_text("private", encoding="utf-8")
    (folder / "sura_114_fast.log").symlink_to(secret)
    assert endpoint("/api/sura/{surah}/logs")(114) == {"logs": []}
    read = endpoint("/api/sura/{surah}/logs/{log_id}")
    for log_id in ("sura_113_fast", "../secret", "sura_114_fast", "sura_114_missing"):
        with pytest.raises(HTTPException) as error:
            read(114, log_id)
        assert error.value.status_code == 404
    assert endpoint("/api/sura/{surah}/logs")(112) == {"logs": []}


def test_saved_sura_logs_require_open_project(project):
    project.db_path = None
    with pytest.raises(HTTPException) as error:
        endpoint("/api/sura/{surah}/logs")(114)
    assert error.value.status_code == 400


def test_job_retains_audio_database_and_logs_when_state_changes(project, tmp_path, monkeypatch):
    from surah_cutter.core import pipeline

    original_db = project.db_path
    original_audio = dict(project.audio_map)
    seen = []
    job = server._GenJob(original_db, project.audio_map)

    def process(audio, surah, **kwargs):
        seen.append(Path(audio))
        project.db_path = tmp_path / "b.db"
        project.audio_map[114] = tmp_path / "b/114.mp3"
        kwargs["log_event"]("test alignment")
        return [(surah, 1, 100)]

    monkeypatch.setattr(pipeline, "process_surah", process)
    # Change the selected DB before the worker even opens its connection.
    project.db_path = tmp_path / "b.db"
    job._run([113, 114], "fast")

    assert seen == [original_audio[113], original_audio[114]]
    assert timings(original_db) == [(113, 1, 100), (114, 1, 100)]
    assert not project.db_path.exists()
    assert (tmp_path / "a.logs/sura_114_fast.log").read_text() == "test alignment\n"
    assert not (tmp_path / "b.logs").exists()
    events = job.events.snapshot()
    assert events[-1] == {"type": "done", "completed": 2}


def test_full_job_saves_trace_confidence_and_preserves_manual_rows(project, monkeypatch):
    from surah_cutter.core import pipeline

    with ProjectDB.open(str(project.db_path), DB_CODE, DB_VERSION) as db:
        db.set_time(114, 1, 6000)
        db.set_status(114, 1, "verified")

    def process(audio, surah, **kwargs):
        kwargs["trace"].update({
            "mode": "full",
            "model_source": "test-model:revision=immutable",
            "backend": "test", "align_lag_ms": 120,
            "lag_adjust_ms": 37,
            "ayahs": [{"ayah": 1, "conf": 0.01}, {"ayah": 2, "conf": 0.15}],
        })
        kwargs["log_event"]("weak-onset")
        return [(114, 1, 5300), (114, 2, 10260)]

    monkeypatch.setattr(pipeline, "process_surah", process)
    job = server._GenJob(project.db_path, project.audio_map)
    job._run([114], "full")

    with ProjectDB.open(str(project.db_path), DB_CODE, DB_VERSION) as db:
        meta = {a: db.get_review(114, a) for a in (1, 2)}
        assert (114, 1, 6000) in db.get_timings()
        assert meta[1]["status"] == "verified"
        assert meta[1]["confidence"] is None
        assert meta[2]["confidence"] == 0.15
        assert meta[2]["source"] == (
            "test-model:revision=immutable:backend=test:requested_mode=full"
            ":actual_mode=full:align_lag_ms=120:lag_adjust_ms=37"
        )
    import json

    saved = json.loads(project.db_path.with_name("a.logs").joinpath("sura_114_full.json").read_text())
    assert saved["trace"]["ayahs"][0]["conf"] == 0.01


def test_full_draft_correction_keeps_confidence_diagnostics(project, monkeypatch):
    from surah_cutter.core import pipeline

    def process(audio, surah, **kwargs):
        kwargs["trace"].update({
            "ayahs": [{"ayah": 1, "conf": 0.03, "reliable": False}],
            "model_source": "correct-model:revision=pinned",
            "backend": "test", "align_lag_ms": 0,
            "mode": "full", "lag_adjust_ms": 0,
        })
        kwargs["log_event"]("weak-onset")
        return [(surah, 1, 6100)]

    monkeypatch.setattr(pipeline, "process_surah", process)
    result = endpoint("/api/sura/{surah}/correct-draft")(114, {"mode": "full"})

    assert result["written"] == 1
    with ProjectDB.open(str(project.db_path), DB_CODE, DB_VERSION) as db:
        assert db.get_review(114, 1)["confidence"] == 0.03
        assert db.get_review(114, 1)["source"] == (
            "correct-model:revision=pinned:backend=test:requested_mode=full"
            ":actual_mode=full:align_lag_ms=0:lag_adjust_ms=0"
        )
    assert project.db_path.with_name("a.logs").joinpath("sura_114_correct-full.log").read_text() == "weak-onset\n"


@pytest.mark.parametrize("path", [
    "/api/sura/{surah}/draft-pauses", "/api/sura/{surah}/correct-draft",
])
def test_draft_write_rejects_request_from_another_project(project, tmp_path, monkeypatch, path):
    from surah_cutter.core import decode, pipeline

    monkeypatch.setattr(decode, "decode", lambda *_: pytest.fail("Stale request must not decode audio"))
    monkeypatch.setattr(pipeline, "process_surah", lambda *_a, **_k:
                        pytest.fail("Stale request must not align audio"))
    with pytest.raises(HTTPException) as exc:
        endpoint(path)(114, {"db_path": str(tmp_path / "previous.db"), "mode": "full"})
    assert exc.value.status_code == 409
    assert timings(project.db_path) == []


def test_running_generation_rejects_project_switch_and_second_start(project, tmp_path, monkeypatch):
    def start(job, *args):
        job.running = True

    monkeypatch.setattr(server._GenJob, "start", start)
    generate = endpoint("/api/generate")
    generate({"suras": [114]})
    job = server._JOB
    with pytest.raises(HTTPException) as exc:
        endpoint("/api/project/open")(
            {"audio_dir": str(tmp_path), "db_path": str(tmp_path / "b.db")}
        )
    assert exc.value.status_code == 409
    assert project.db_path == tmp_path / "a.db"
    assert 114 in project.audio_map
    with pytest.raises(HTTPException) as exc:
        generate({"suras": [113]})
    assert exc.value.status_code == 409
    assert server._JOB is job


def test_resume_fills_partial_sura_and_preserves_manual_ayahs(project, monkeypatch):
    from surah_cutter.core import pipeline

    with ProjectDB.open(str(project.db_path), DB_CODE, DB_VERSION) as db:
        db.write_timings([(113, a, a * 1000) for a in range(1, 6)], source="auto")
        db.set_time(114, 1, 123)
        db.set_time(114, 2, 456)
        db.set_status(114, 2, "verified")
    statuses = {row["surah"]: row["status"] for row in endpoint("/api/suras")()}
    assert statuses[113] == "processed"
    assert statuses[114] == "partial"
    assert server._processed_suras() == {113}

    monkeypatch.setattr(
        pipeline,
        "process_surah",
        lambda audio, surah, **kw: [(surah, a, a * 1000)
                                  for a in range(1, server.quran_text.ayah_count(surah) + 1)],
    )
    monkeypatch.setattr(server._GenJob, "start", server._GenJob._run)
    result = endpoint("/api/generate")({"only_missing": True})
    assert result["suras"] == [113, 114]
    assert timings(project.db_path)[5:] == [
        (114, 1, 123),
        (114, 2, 456),
        *[(114, a, a * 1000) for a in range(3, 7)],
    ]
    with sqlite3.connect(project.db_path) as conn:
        assert conn.execute(
            "SELECT status FROM review_meta WHERE sura=114 AND ayah<=2 ORDER BY ayah"
        ).fetchall() == [("edited",), ("verified",)]
    assert server._processed_suras() == {113, 114}


def test_wrong_ayah_set_is_partial_even_with_expected_row_count(project):
    with ProjectDB.open(str(project.db_path), DB_CODE, DB_VERSION) as db:
        db._conn.executemany("INSERT INTO timings VALUES (?, ?, ?)",
                             [(114, a, a * 1000) for a in [1, 2, 3, 4, 5, 999]])
        db._conn.commit()
    assert server._processed_suras() == set()
    statuses = {row["surah"]: row["status"] for row in endpoint("/api/suras")()}
    assert statuses[114] == "partial"


@pytest.mark.parametrize(
    "statuses,count,expected",
    [
        (None, 6, "not-processed"),
        (["verified"], 6, "partial"),
        (["auto"] * 6, 6, "processed"),
        (["verified"] * 6, 6, "verified"),
    ],
)
def test_classify_completeness(statuses, count, expected):
    assert classify_status(statuses, count) == expected


def test_pause_draft_keeps_original_database_after_decode(project, tmp_path, monkeypatch):
    from surah_cutter.core import decode, draft

    original_db = project.db_path
    with ProjectDB.open(str(original_db), DB_CODE, DB_VERSION) as db:
        db.set_time(114, 1, 123)

    def decode_audio(audio):
        assert Path(audio) == project.audio_map[114]
        project.db_path = tmp_path / "b.db"
        return []

    def draft_audio(pcm, sr, surah, anchors):
        assert anchors == {1: 123}
        return SimpleNamespace(
            rows=[(114, 1, 999), (114, 2, 1000)],
            pause_count=1,
            pause_backed=1,
            interpolated=0,
            anchored=1,
        )

    monkeypatch.setattr(decode, "decode", decode_audio)
    monkeypatch.setattr(draft, "draft_from_pauses", draft_audio)
    assert endpoint("/api/sura/{surah}/draft-pauses")(114)["written"] == 1
    assert timings(original_db) == [(114, 1, 123), (114, 2, 1000)]
    assert not project.db_path.exists()


def test_failed_project_open_does_not_publish_partial_state(project, tmp_path):
    original_map = dict(project.audio_map)
    with pytest.raises(sqlite3.OperationalError):
        endpoint("/api/project/open")({"audio_dir": str(tmp_path), "db_path": str(tmp_path)})
    assert project.db_path == tmp_path / "a.db"
    assert project.audio_dir is None
    assert project.audio_map == original_map


@pytest.fixture
def word_project(project, monkeypatch):
    from surah_cutter.core import decode

    with ProjectDB.open(str(project.db_path), DB_CODE, DB_VERSION) as db:
        db.write_timings([(114, 1, 1000), (114, 2, 5000)], "test")
    monkeypatch.setattr(decode, "duration_ms", lambda _: 30000)
    return project


def test_word_api_manual_edit_verify_stale_and_bounds(word_project):
    get = endpoint("/api/sura/{surah}/ayah/{ayah}/words")
    edit = endpoint("/api/sura/{surah}/ayah/{ayah}/words/edit")
    data = get(114, 1)
    words = server.quran_text.surah_words(114)
    assert [w["text"] for w in data["words"]] == [w.text for w in words if w.ayah == 1]
    payload = {"db_path": data["db_path"], "start_ms": 1000, "end_ms": 5000,
               "word_index": data["words"][0]["word_index"], "time": 1200}
    result = edit(114, 1, payload)
    assert result["words"][0]["status"] == "edited"
    assert edit(114, 1, {**payload, "action": "verify"})["words"][0]["status"] == "verified"
    for invalid in [True, -1, 5000, 1200.5]:
        with pytest.raises(HTTPException) as exc:
            edit(114, 1, {**payload, "time": invalid})
        assert exc.value.status_code == 400
    with pytest.raises(HTTPException):
        edit(114, 1, {**payload, "word_index": 9999})
    with ProjectDB.open(str(word_project.db_path), DB_CODE, DB_VERSION) as db:
        db.set_time(114, 2, 5500)
    assert get(114, 1)["words"][0]["stale"]
    with pytest.raises(HTTPException) as exc:
        edit(114, 1, payload)
    assert exc.value.status_code == 409
    payload["end_ms"] = 5500
    with pytest.raises(HTTPException):
        edit(114, 1, {**payload, "action": "verify"})
    assert not edit(114, 1, payload)["words"][0]["stale"]


def test_word_api_requires_adjacent_boundaries_and_current_project(word_project):
    get = endpoint("/api/sura/{surah}/ayah/{ayah}/words")
    with pytest.raises(HTTPException):
        get(114, 2)  # No ayah 3; cannot use the end of the surah for ayah 2.
    with pytest.raises(HTTPException) as exc:
        endpoint("/api/sura/{surah}/ayah/{ayah}/words/edit")(114, 1, {"db_path": "wrong"})
    assert exc.value.status_code == 409


def test_word_status_round_trip_preserves_time_and_manual_protection(word_project):
    get = endpoint("/api/sura/{surah}/ayah/{ayah}/words")
    edit = endpoint("/api/sura/{surah}/ayah/{ayah}/words/edit")
    data = get(114, 1)
    index = data["words"][0]["word_index"]
    payload = {"db_path": data["db_path"], "start_ms": 1000, "end_ms": 5000,
               "word_index": index, "time": 1200}
    edit(114, 1, payload)
    for status in ("verified", "edited", "auto"):
        result = edit(114, 1, {**payload, "action": "status", "status": status})
        assert (result["words"][0]["status"], result["words"][0]["time"]) == (status, 1200)
        if status != "auto":
            with ProjectDB.open(str(word_project.db_path), DB_CODE, DB_VERSION) as db:
                assert db.write_word_timings(114, 1, [(index, 1300, .9)], 1000, 5000, "test") == 0
    for invalid in ("bad", None):
        with pytest.raises(HTTPException) as exc:
            edit(114, 1, {**payload, "action": "status", "status": invalid})
        assert exc.value.status_code == 400
    assert get(114, 1)["words"][0]["status"] == "auto"


def test_word_status_cannot_accept_missing_or_stale_mark(word_project):
    get = endpoint("/api/sura/{surah}/ayah/{ayah}/words")
    edit = endpoint("/api/sura/{surah}/ayah/{ayah}/words/edit")
    data = get(114, 1)
    payload = {"db_path": data["db_path"], "start_ms": 1000, "end_ms": 5000,
               "word_index": data["words"][0]["word_index"], "action": "status"}
    for status in ("auto", "edited", "verified"):
        with pytest.raises(HTTPException) as exc:
            edit(114, 1, {**payload, "status": status})
        assert exc.value.status_code == 400
    edit(114, 1, {**payload, "action": "set_time", "time": 1200})
    with ProjectDB.open(str(word_project.db_path), DB_CODE, DB_VERSION) as db:
        db.set_time(114, 2, 5500)
    for status in ("auto", "edited", "verified"):
        with pytest.raises(HTTPException) as exc:
            edit(114, 1, {**payload, "end_ms": 5500, "status": status})
        assert exc.value.status_code == 400
    word = get(114, 1)["words"][0]
    assert word["stale"] and word["status"] == "edited" and word["time"] == 1200


def test_word_alignment_rejects_changed_project_before_write(word_project, monkeypatch):
    from surah_cutter.core import decode, word_align
    import numpy as np

    get = endpoint("/api/sura/{surah}/ayah/{ayah}/words")
    data = get(114, 1)
    payload = {"db_path": data["db_path"], "start_ms": 1000, "end_ms": 5000}
    monkeypatch.setattr(decode, "decode_range", lambda *a, **kw: np.zeros(64000))

    def compute(pcm, sr, words):
        with ProjectDB.open(str(word_project.db_path), DB_CODE, DB_VERSION) as db:
            db.set_time(114, 2, 5500)
        return [(w.index, 100 + i * 500, .9) for i, w in enumerate(words)]

    monkeypatch.setattr(word_align, "align_ayah_words", compute)
    with pytest.raises(HTTPException) as exc:
        endpoint("/api/sura/{surah}/ayah/{ayah}/words/align")(114, 1, payload)
    assert exc.value.status_code == 409
    with ProjectDB.open(str(word_project.db_path), DB_CODE, DB_VERSION) as db:
        assert db.get_word_timings(114, 1) == []
    assert not server._WORD_LOCK.locked()


def test_word_alignment_saves_all_words_without_changing_ayahs(word_project, monkeypatch):
    from surah_cutter.core import decode, word_align
    import numpy as np

    data = endpoint("/api/sura/{surah}/ayah/{ayah}/words")(114, 1)
    payload = {"db_path": data["db_path"], "start_ms": 1000, "end_ms": 5000}
    monkeypatch.setattr(decode, "decode_range", lambda *a, **kw: np.zeros(64000))
    monkeypatch.setattr(word_align, "align_ayah_words", lambda pcm, sr, words:
                        [(w.index, 100 + i * 500, .9) for i, w in enumerate(words)])
    before = timings(word_project.db_path)
    result = endpoint("/api/sura/{surah}/ayah/{ayah}/words/align")(114, 1, payload)
    assert all(w["status"] == "auto" for w in result["words"])
    assert len(result["words"]) == len(data["words"])
    assert timings(word_project.db_path) == before


@pytest.fixture
def complete_word_project(word_project):
    with ProjectDB.open(str(word_project.db_path), DB_CODE, DB_VERSION) as db:
        db.write_timings([(114, a, t) for a, t in enumerate(
            [1000, 5000, 10000, 15000, 20000, 25000], 1)], "test")
    return word_project


def test_word_sura_job_keeps_ayahs_and_preserves_verified_word(complete_word_project, monkeypatch):
    from surah_cutter.core import decode, pipeline, word_align
    import numpy as np

    monkeypatch.setattr(decode, "decode", lambda _: np.zeros(480000))
    def unexpected(*args, **kwargs):
        pytest.fail("Complete ayah marks must not be regenerated in words mode")
    monkeypatch.setattr(pipeline, "process_surah", unexpected)
    monkeypatch.setattr(word_align, "align_ayah_words", lambda pcm, sr, words:
                        [(w.index, 50 + i * 500, .9) for i, w in enumerate(words)])
    path = complete_word_project.db_path
    with ProjectDB.open(str(path), DB_CODE, DB_VERSION) as db:
        db.set_word_time(114, 1, 0, 1100, 1000, 5000)
        db.verify_word(114, 1, 0, 1000, 5000)
    before = timings(path)
    job = server._GenJob(path, complete_word_project.audio_map)
    job._run([114], "words")
    assert timings(path) == before
    event = next(e for e in job.events.snapshot() if e and e["type"] == "sura")
    assert event["words_written"] == len(server.quran_text.surah_words(114)) - 1
    assert event["word_failures"] == 0
    assert event["written"] == 0
    with ProjectDB.open(str(path), DB_CODE, DB_VERSION) as db:
        assert db.get_word_timings(114, 1)[0]["time"] == 1100
        assert db.get_word_timings(114, 1)[0]["status"] == "verified"
    assert server._word_progress()[114]["complete"]
    with ProjectDB.open(str(path), DB_CODE, DB_VERSION) as db:
        db.set_time(114, 2, 5100)
    assert not server._word_progress()[114]["complete"]


def test_word_resume_uses_words_not_ayah_completeness(complete_word_project, monkeypatch):
    started = []
    monkeypatch.setattr(server._GenJob, "start", lambda job, suras, mode:
                        started.append((suras, mode)))
    result = endpoint("/api/generate")({"suras": [114], "mode": "words", "only_missing": True})
    assert result["mode"] == "words"
    assert started == [([114], "words")]
    with ProjectDB.open(str(complete_word_project.db_path), DB_CODE, DB_VERSION) as db:
        marks = {a: t for s, a, t in db.get_timings() if s == 114}
        for a in range(1, 7):
            words = [w for w in server.quran_text.surah_words(114) if w.ayah == a]
            db.write_word_timings(114, a, [(w.index, marks[a] + i * 100, .8)
                                          for i, w in enumerate(words)],
                                  marks[a], marks.get(a + 1, 30000), "test")
    with pytest.raises(HTTPException) as exc:
        endpoint("/api/generate")({"suras": [114], "mode": "words", "only_missing": True})
    assert exc.value.status_code == 400
    assert endpoint("/api/settings")({"mode": "words"})["mode"] == "words"


def test_word_sura_job_reports_unaligned_ayah_and_continues(complete_word_project, monkeypatch):
    from surah_cutter.core import decode, word_align
    import numpy as np

    monkeypatch.setattr(decode, "decode", lambda _: np.zeros(480000))
    def compute(pcm, sr, words):
        if words[0].ayah == 3:
            raise ValueError("incomplete path")
        return [(w.index, 50 + i * 500, .9) for i, w in enumerate(words)]
    monkeypatch.setattr(word_align, "align_ayah_words", compute)
    job = server._GenJob(complete_word_project.db_path, complete_word_project.audio_map)
    job._run([114], "words")
    event = next(e for e in job.events.snapshot() if e and e["type"] == "sura")
    assert event["word_failures"] == 1
    assert not server._word_progress()[114]["complete"]
    with ProjectDB.open(str(complete_word_project.db_path), DB_CODE, DB_VERSION) as db:
        assert not db.get_word_timings(114, 3)
        assert db.get_word_timings(114, 6)


def test_word_mode_builds_missing_ayah_marks_with_fast(project, monkeypatch):
    from surah_cutter.core import pipeline

    seen = []
    def process(audio, surah, **kwargs):
        seen.append(kwargs["mode"])
        return [(114, a, a * 1000) for a in range(1, 7)]
    monkeypatch.setattr(pipeline, "process_surah", process)
    monkeypatch.setattr(server, "_align_sura_words", lambda *args:
                        {"words_written": 20, "word_failures": 0})
    job = server._GenJob(project.db_path, project.audio_map)
    job._run([114], "words")
    assert seen == ["fast"]
    assert len(timings(project.db_path)) == 6



def test_sura_words_returns_one_canonical_list_with_edit_context(complete_word_project):
    get = endpoint("/api/sura/{surah}/words")
    with ProjectDB.open(str(complete_word_project.db_path), DB_CODE, DB_VERSION) as db:
        db.set_word_time(114, 1, 0, 1200, 1000, 5000)
    data = get(114)
    canonical = server.quran_text.surah_words(114)
    assert [w["text"] for w in data["words"]] == [w.text for w in canonical]
    assert [w["word_index"] for w in data["words"]] == [w.index for w in canonical]
    assert [w["number"] for w in data["words"][:4]] == [1, 2, 3, 4]
    assert data["words"][4]["ayah"] == 2
    assert data["words"][4]["number"] == 1
    assert (data["words"][0]["start_ms"], data["words"][0]["end_ms"]) == (1000, 5000)
    assert data["words"][-1]["end_ms"] == 30000
    assert not data["words"][0]["stale"]
    with ProjectDB.open(str(complete_word_project.db_path), DB_CODE, DB_VERSION) as db:
        db.set_time(114, 2, 5100)
    assert get(114)["words"][0]["stale"]


@pytest.mark.parametrize("theme", ["light", "dark"])
def test_settings_theme_survives_reload(project, tmp_path, monkeypatch, theme):
    from surah_cutter.webgui import settings

    monkeypatch.setattr(settings, "SETTINGS_PATH", tmp_path / "settings.json")
    # The shared fixture stubs persistence; restore it for this regression.
    def persist(**fields):
        strict = fields.pop("strict", False)
        data = settings.load()
        data.update(fields)
        settings.save(data, strict=strict)
        return data

    monkeypatch.setattr(settings, "update", persist)
    settings.save({"mode": "words", "arabic_size": 36})
    assert endpoint("/api/settings")({"theme": theme})["theme"] == theme
    assert endpoint("/api/project")()["theme"] == theme
    assert settings.load()["mode"] == "words"
    assert settings.load()["arabic_size"] == 36


@pytest.mark.parametrize("theme", ["system", "", None, 1, []])
def test_settings_rejects_invalid_theme(project, theme):
    with pytest.raises(HTTPException) as exc:
        endpoint("/api/settings")({"theme": theme})
    assert exc.value.status_code == 400


def test_settings_defaults_to_light(project, monkeypatch):
    monkeypatch.setattr(server.settings, "load", lambda: {})
    assert endpoint("/api/project")()["theme"] == "light"


def test_external_project_names_persist_per_database(project, tmp_path, monkeypatch):
    monkeypatch.setattr(server.settings, "SETTINGS_PATH", tmp_path / "settings.json")
    monkeypatch.setattr(server.projects, "list_projects", lambda: [])

    def persist(*, strict=False, **fields):
        data = server.settings.load()
        data.update(fields)
        server.settings.save(data, strict=strict)
        return data

    monkeypatch.setattr(server.settings, "update", persist)
    before = project.db_path.read_bytes()
    endpoint("/api/settings")({
        "db_path": str(project.db_path), "reciter": " Новый чтец ", "recording": "Запись",
    })
    assert endpoint("/api/project")()["reciter"] == "Новый чтец"
    assert endpoint("/api/project")()["recording"] == "Запись"
    assert project.db_path.read_bytes() == before
    original = project.db_path
    project.db_path = tmp_path / "other.db"
    assert endpoint("/api/project")()["recording"] == "Внешний проект"
    with pytest.raises(HTTPException) as exc:
        endpoint("/api/settings")({"db_path": str(original), "reciter": "X", "recording": "Y"})
    assert exc.value.status_code == 409
    project.db_path = original
    for name in ("", " " * 3, "x" * 121, 123):
        with pytest.raises(HTTPException) as exc:
            endpoint("/api/settings")({"db_path": str(original), "reciter": name, "recording": "Y"})
        assert exc.value.status_code == 400
    assert endpoint("/api/project")()["reciter"] == "Новый чтец"


def test_cancel_current_sura_does_not_write_computed_rows(project, monkeypatch):
    from surah_cutter.core import pipeline

    job = server._GenJob(project.db_path, project.audio_map)
    calls = []

    def process(audio, surah, **kwargs):
        calls.append(surah)
        job.request_cancel()
        return [(surah, 1, 100)]

    monkeypatch.setattr(pipeline, "process_surah", process)
    job._run([113, 114], "full")
    assert calls == [113]
    assert timings(project.db_path) == []
    assert job.events.snapshot()[-1:] == [{"type": "cancelled", "completed": 0}]
    assert not job.running
    assert server.model_store.RUNTIME_LOCK.acquire(blocking=False)
    server.model_store.RUNTIME_LOCK.release()
    # A fresh job can write immediately after cancellation.
    monkeypatch.setattr(pipeline, "process_surah", lambda audio, surah, **kw: [(surah, 1, 100)])
    retry = server._GenJob(project.db_path, project.audio_map)
    retry._run([114], "full")
    assert timings(project.db_path) == [(114, 1, 100)]
    assert retry.events.snapshot()[-1:] == [{"type": "done", "completed": 1}]


def test_cancel_words_preserves_finished_ayah_and_manual_marks(complete_word_project, monkeypatch):
    from surah_cutter.core import decode, word_align
    import numpy as np

    monkeypatch.setattr(decode, "decode", lambda _: np.zeros(480000))
    path = complete_word_project.db_path
    with ProjectDB.open(str(path), DB_CODE, DB_VERSION) as db:
        db.set_word_time(114, 1, 0, 1100, 1000, 5000)
        db.verify_word(114, 1, 0, 1000, 5000)
    before = timings(path)
    job = server._GenJob(path, complete_word_project.audio_map)
    calls = []

    def align(pcm, sr, words):
        ayah = words[0].ayah
        calls.append(ayah)
        if ayah == 2:
            job.request_cancel()
        return [(w.index, 50 + i * 500, .9) for i, w in enumerate(words)]

    monkeypatch.setattr(word_align, "align_ayah_words", align)
    job._run([114], "words")
    assert calls == [1, 2]
    assert timings(path) == before
    with ProjectDB.open(str(path), DB_CODE, DB_VERSION) as db:
        first = db.get_word_timings(114, 1)
        assert len(first) > 1
        assert first[0]["time"] == 1100
        assert first[0]["status"] == "verified"
        assert db.get_word_timings(114, 2) == []
    assert job.events.snapshot()[-1:] == [{"type": "cancelled", "completed": 0}]
