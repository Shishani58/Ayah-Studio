"""QPC FULL phrase recheck for first words split across a confirmed pause."""

from __future__ import annotations

import numpy as np

from surah_cutter.core.cancellation import GenerationCancelled, check_cancelled


def _consonants(text: str) -> str:
    letters = [c for c in text if c.isalpha() and c not in "aeiouāīū"]
    # Greedy CTC can merge geminated consonants. Targets keep their exact
    # spelling; this normalization is used only for independent phrase matching.
    return "".join(c for i, c in enumerate(letters) if i == 0 or c != letters[i - 1])


def recheck_split_words(
    bundle, pcm, sr, words, word_spans, spans, frame_scores, stride_ms, checks,
    pauses, *, base_ms=0, trace=None,
):
    from surah_cutter.core import align, candidates
    from surah_cutter.core._ctc import aligned_segments, forced_align
    from surah_cutter.data import transliteration

    reads = trace.setdefault("full_boundary_reads", []) if trace is not None else []
    trs = transliteration.surah_word_tr(words[0].surah)
    inverse = {v: k for k, v in bundle.vocab.items()}
    seen = set()
    for wi, word in enumerate(words):
        check_cancelled()
        if word.ayah in seen:
            continue
        seen.add(word.ayah)
        check = checks[word.ayah]
        if check["repaired"] or wi + 1 >= len(words) or words[wi + 1].ayah != word.ayah:
            continue
        ts, te = word_spans[wi]
        first = base_ms + spans[ts][0] * stride_ms
        last = base_ms + spans[te - 1][0] * stride_ms
        split = [p for p in pauses if first < p.start_ms < p.end_ms <= last and p.depth_ms >= 300]
        if len(split) != 1:
            continue
        pause = split[0]
        if not candidates._dsp_accepts_pause(candidates._dsp_pause_metrics(pcm, sr, pause)):
            continue
        # A supported consonant on the left may belong to an interrupted word.
        # Only vowels/formatting or unsupported consonants may be reassigned.
        first_targets, _ = align._build_targets([word], [trs[word.index]], bundle, None)
        if any(
            _consonants(inverse[token]) and align._span_confidence(frame_scores, sf, ef) >= .25
            for token, (sf, ef) in zip(first_targets, spans[ts:te])
            if base_ms + sf * stride_ms < pause.end_ms
        ):
            continue
        count = 2
        while (count < 3 and wi + count < len(words) and words[wi + count].ayah == word.ayah
               and len("".join(_consonants(trs[w.index]) for w in words[wi:wi + count])) < 6):
            count += 1
        selected_words = words[wi:wi + count]
        selected_trs = [trs[w.index] for w in selected_words]
        opening = "".join(_consonants(tr) for tr in selected_trs)
        if not _consonants(selected_trs[0]) or len(opening) < 6:
            continue
        context_end = base_ms + (spans[word_spans[wi + count - 1][1] - 1][1] + 1) * stride_ms + 100
        lo = round(max(pause.center_ms, pause.end_ms - 200) / 20) * 20
        hi = round(min(len(pcm) * 1000 / sr, context_end) / 20) * 20
        if not 500 <= hi - lo <= 6000:
            continue
        crop = pcm[round(lo * sr / 1000):round(hi * sr / 1000)]
        record = {"ayah": word.ayah, "start_ms": lo, "end_ms": hi,
                  "frames": 0, "accepted": False, "outcome": "running",
                  "target": selected_trs, "normalization": "local"}
        check_cancelled()
        reads.append(record)
        try:
            matrix = bundle.emitter.emissions(crop)
            check_cancelled()
        except GenerationCancelled:
            record["outcome"] = "cancelled"
            raise
        except Exception:
            record["outcome"] = "failed"
            raise
        record.update(outcome="completed", frames=len(matrix))
        ids = matrix.argmax(axis=1)
        decoded = "".join(inverse[int(token)] for i, token in enumerate(ids)
                          if token != bundle.blank_id and (i == 0 or token != ids[i - 1]))
        record["decoded"] = decoded
        if not _consonants(decoded).startswith(opening):
            record["reason"] = "greedy-opening-mismatch"
            continue
        targets, local_words = align._build_targets(selected_words, selected_trs, bundle, None)
        try:
            path, scores = forced_align(matrix[None], np.asarray(targets)[None], blank=bundle.blank_id)
            segments = aligned_segments(path.reshape(-1), targets, blank=bundle.blank_id)
        except ValueError:
            record["reason"] = "insufficient-local-path"
            continue
        local_spans = [(s.start, s.end) for s in segments]
        local_stride = align._stride_ms(len(crop), sr, len(matrix))
        local = align._check_ayah_onsets(
            selected_words, local_words, local_spans, scores.reshape(-1), local_stride,
            pauses=[], base_ms=lo, lag_ms=bundle.lag_ms,
        )[word.ayah]
        chars = [inverse[targets[i]] for i in range(*local_words[0])]
        consonant_conf = [c for char, c in zip(chars, local["token_confs"]) if _consonants(char)]
        record.update(local_check=local, consonant_conf=consonant_conf)
        if (min(consonant_conf, default=0) < .45 or local["conf"] < .25
                or not pause.center_ms <= local["onset_ms"] <= pause.end_ms + 200):
            record["reason"] = "insufficient-local-word-evidence"
            continue
        new_ms = local["onset_ms"]
        if any((a < word.ayah and c["onset_ms"] >= new_ms)
               or (a > word.ayah and c["onset_ms"] <= new_ms) for a, c in checks.items()):
            record["reason"] = "conflicting-ayah-order"
            continue
        old_ms = check["onset_ms"]
        check.update(
            onset_ms=new_ms, conf=local["conf"], first_token_conf=local["first_token_conf"],
            token_confs=local["token_confs"], reliable=check["reliable"] and local["reliable"],
            repaired=True, reason="split-word-local-recheck", original_conf=check["conf"],
            original_first_token_conf=check["first_token_conf"],
            pause_start_ms=pause.start_ms, pause_end_ms=pause.end_ms,
        )
        record.update(accepted=True, reason="split-word-local-recheck", before_ms=old_ms, after_ms=new_ms)
